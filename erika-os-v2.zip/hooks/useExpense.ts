"use client";

import { useEffect, useState } from "react";

import ExpenseService from "@/services/expense.service";

import { Expense } from "@/types";

export default function useExpense() {

  const [expenses, setExpenses] =
    useState<Expense[]>([]);

  useEffect(() => {

    setExpenses(
      ExpenseService.getAll()
    );

  }, []);

  function addExpense(
    expense: Expense
  ) {

    ExpenseService.create(expense);

    setExpenses(
      ExpenseService.getAll()
    );

  }

  function updateExpense(
    expense: Expense
  ) {

    ExpenseService.update(expense);

    setExpenses(
      ExpenseService.getAll()
    );

  }

  function deleteExpense(
    id: string
  ) {

    ExpenseService.delete(id);

    setExpenses(
      ExpenseService.getAll()
    );

  }

  const totalExpense =
    expenses.reduce(
      (total, item) =>
        total + item.amount,
      0
    );

  return {

    expenses,

    totalExpense,

    addExpense,

    updateExpense,

    deleteExpense,

  };

}