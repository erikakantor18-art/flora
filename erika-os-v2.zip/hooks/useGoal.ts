"use client";

import { useEffect, useState } from "react";

import GoalService from "@/services/goal.service";

import { Goal } from "@/types";

export default function useGoal() {

  const [goals, setGoals] =
    useState<Goal[]>([]);

  useEffect(() => {

    setGoals(
      GoalService.getAll()
    );

  }, []);

  function addGoal(goal: Goal) {

    GoalService.create(goal);

    setGoals(
      GoalService.getAll()
    );

  }

  function updateGoal(goal: Goal) {

    GoalService.update(goal);

    setGoals(
      GoalService.getAll()
    );

  }

  function deleteGoal(id: string) {

    GoalService.delete(id);

    setGoals(
      GoalService.getAll()
    );

  }

  return {

    goals,

    addGoal,

    updateGoal,

    deleteGoal,

  };

}