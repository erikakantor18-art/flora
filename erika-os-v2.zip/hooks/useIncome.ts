"use client";

import { useEffect, useState } from "react";

import toast from "react-hot-toast";

import {
  getIncome,
  addIncome as createIncome,
  updateIncome as editIncome,
  deleteIncome as removeIncome,
} from "@/services/income.service";

import { Income } from "@/types";

export default function useIncome() {

  const [income, setIncome] =
    useState<Income[]>([]);

  const [loading, setLoading] =
    useState(false);

  async function loadIncome() {

    try {

      setLoading(true);

      const data =
        await getIncome();

      setIncome(data);

    } catch (error: any) {

      console.error(error);

      toast.error(
        error.message ??
        "Failed to load income."
      );

    } finally {

      setLoading(false);

    }

  }

  useEffect(() => {

    loadIncome();

  }, []);

  async function addIncome(
    item: Income
  ) {

    try {

      setLoading(true);

      await createIncome(item);

      toast.success(
        "Income added."
      );

      await loadIncome();

    } catch (error: any) {

      console.error(error);

      toast.error(
        error.message ??
        "Failed to add income."
      );

    } finally {

      setLoading(false);

    }

  }

  async function updateIncome(
    item: Income
  ) {

    try {

      setLoading(true);

      await editIncome(item);

      toast.success(
        "Income updated."
      );

      await loadIncome();

    } catch (error: any) {

      console.error(error);

      toast.error(
        error.message ??
        "Failed to update income."
      );

    } finally {

      setLoading(false);

    }

  }

  async function deleteIncome(
    id: string
  ) {

    try {

      setLoading(true);

      await removeIncome(id);

      toast.success(
        "Income deleted."
      );

      await loadIncome();

    } catch (error: any) {

      console.error(error);

      toast.error(
        error.message ??
        "Failed to delete income."
      );

    } finally {

      setLoading(false);

    }

  }

  const totalIncome =
    income.reduce(
      (total, item) =>
        total + item.amount,
      0
    );

  return {

    income,

    loading,

    totalIncome,

    addIncome,

    updateIncome,

    deleteIncome,

    reload: loadIncome,

  };

}