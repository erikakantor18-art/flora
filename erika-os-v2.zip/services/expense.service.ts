import { Expense } from "@/types";

const KEY = "expenses";

class ExpenseService {

  getAll(): Expense[] {

    if (typeof window === "undefined")
      return [];

    const data =
      localStorage.getItem(KEY);

    return data
      ? JSON.parse(data)
      : [];

  }

  save(expenses: Expense[]) {

    localStorage.setItem(
      KEY,
      JSON.stringify(expenses)
    );

  }

  create(expense: Expense) {

    const data = this.getAll();

    data.push(expense);

    this.save(data);

  }

  update(expense: Expense) {

    const data = this.getAll().map(
      (item) =>
        item.id === expense.id
          ? expense
          : item
    );

    this.save(data);

  }

  delete(id: string) {

    const data =
      this.getAll().filter(
        (item) => item.id !== id
      );

    this.save(data);

  }

}

export default new ExpenseService();