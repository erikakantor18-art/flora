import { Goal } from "@/types";

const KEY = "goals";

class GoalService {

  getAll(): Goal[] {

    if (typeof window === "undefined")
      return [];

    const data = localStorage.getItem(KEY);

    return data ? JSON.parse(data) : [];

  }

  save(goals: Goal[]) {

    localStorage.setItem(
      KEY,
      JSON.stringify(goals)
    );

  }

  create(goal: Goal) {

    const goals = this.getAll();

    goals.push(goal);

    this.save(goals);

  }

  update(goal: Goal) {

    const goals = this.getAll().map((item) =>
      item.id === goal.id ? goal : item
    );

    this.save(goals);

  }

  delete(id: string) {

    const goals = this.getAll().filter(
      (item) => item.id !== id
    );

    this.save(goals);

  }

}

export default new GoalService();