import Card from "@/components/ui/Card";

import {
  Wallet,
  Target,
  BookOpen,
  Plane,
} from "lucide-react";

const actions = [
  {
    title: "Finance",
    icon: <Wallet size={24} />,
    color: "bg-green-500",
  },
  {
    title: "Goals",
    icon: <Target size={24} />,
    color: "bg-red-500",
  },
  {
    title: "Study",
    icon: <BookOpen size={24} />,
    color: "bg-blue-500",
  },
  {
    title: "Australia",
    icon: <Plane size={24} />,
    color: "bg-yellow-500",
  },
];

export default function QuickAction() {
  return (
    <Card>

      <h2 className="text-2xl font-bold">
        Quick Actions
      </h2>

      <div className="mt-6 grid grid-cols-2 gap-4">

        {actions.map((action) => (

          <button
            key={action.title}
            className={`${action.color} rounded-2xl p-6 text-white transition hover:scale-105`}
          >

            <div className="flex flex-col items-center gap-3">

              {action.icon}

              <p className="font-semibold">
                {action.title}
              </p>

            </div>

          </button>

        ))}

      </div>

    </Card>
  );
}