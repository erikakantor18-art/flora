import Card from "@/components/ui/Card";

type Expense = {
  name: string;
  amount: number;
  category: string;
};

type Props = {
  expenses: Expense[];
};

export default function RecentExpense({
  expenses,
}: Props) {
  return (
    <Card>

      <h2 className="text-2xl font-bold">
        Recent Expense
      </h2>

      <div className="mt-6 space-y-4">

        {expenses.slice(0, 5).map((expense, index) => (

          <div
            key={index}
            className="flex items-center justify-between rounded-xl bg-slate-100 p-4"
          >

            <div>

              <p className="font-semibold">
                {expense.name}
              </p>

              <p className="text-sm text-slate-500">
                {expense.category}
              </p>

            </div>

            <p className="font-bold">

              Rp{" "}

              {expense.amount.toLocaleString("id-ID")}

            </p>

          </div>

        ))}

      </div>

    </Card>
  );
}