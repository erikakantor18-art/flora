"use client";

import Card from "@/components/ui/Card";

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
} from "chart.js";

import { Line } from "react-chartjs-2";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend
);

type Expense = {
  name: string;
  amount: number;
  category: string;
};

type Props = {
  expenses: Expense[];
};

export default function ExpenseOverview({
  expenses,
}: Props) {

  const labels = expenses.map((_, index) => `#${index + 1}`);

  const data = {
    labels,

    datasets: [
      {
        label: "Expense",

        data: expenses.map((e) => e.amount),

        borderColor: "#22c55e",

        backgroundColor: "rgba(34,197,94,.2)",

        tension: 0.4,

        fill: true,
      },
    ],
  };

  return (
    <Card>

      <h2 className="text-2xl font-bold">
        Expense Overview
      </h2>

      <p className="mt-2 text-slate-500">
        Every transaction you add will appear here.
      </p>

      <div className="mt-8">

        <Line data={data} />

      </div>

    </Card>
  );
}