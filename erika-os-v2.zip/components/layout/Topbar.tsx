"use client";

import {
  Bell,
  Moon,
  Search,
} from "lucide-react";

export default function Topbar() {
  return (
    <header className="flex items-center justify-between rounded-3xl border border-slate-200 bg-white/80 p-6 backdrop-blur-md shadow-sm">

      <div>

        <h1 className="text-3xl font-black text-slate-800">
          Erika OS
        </h1>

        <p className="mt-1 text-slate-500">
          Welcome back 👋
        </p>

      </div>

      <div className="flex items-center gap-4">

        <div className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3">

          <Search
            size={18}
            className="text-slate-400"
          />

          <input
            placeholder="Search..."
            className="w-64 bg-transparent outline-none"
          />

        </div>

        <button className="rounded-2xl border border-slate-200 p-3 transition hover:bg-slate-100">

          <Bell size={20} />

        </button>

        <button className="rounded-2xl border border-slate-200 p-3 transition hover:bg-slate-100">

          <Moon size={20} />

        </button>

        <div className="flex items-center gap-3 rounded-2xl bg-green-600 px-4 py-2 text-white">

          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-white text-lg font-bold text-green-600">

            E

          </div>

          <div>

            <p className="font-semibold">
              Erika
            </p>

            <p className="text-xs opacity-80">
              Personal Dashboard
            </p>

          </div>

        </div>

      </div>

    </header>
  );
}