"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import {
  LayoutDashboard,
  Wallet,
  Target,
  BookOpen,
  Plane,
  Settings,
} from "lucide-react";

const menus = [
  {
    name: "Dashboard",
    href: "/dashboard",
    icon: LayoutDashboard,
  },
  {
    name: "Finance",
    href: "/finance",
    icon: Wallet,
  },
  {
    name: "Goals",
    href: "/goals",
    icon: Target,
  },
  {
    name: "Study",
    href: "/study",
    icon: BookOpen,
  },
  {
    name: "Australia",
    href: "/australia",
    icon: Plane,
  },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="flex h-screen w-72 flex-col border-r border-slate-800 bg-slate-950 text-white">

      <div className="border-b border-slate-800 p-8">

        <h1 className="text-3xl font-black">
          🌿 Erika OS
        </h1>

        <p className="mt-2 text-sm text-slate-400">
          Personal Life Operating System
        </p>

      </div>

      <nav className="flex-1 px-4 py-6">

        {menus.map((menu) => {

          const Icon = menu.icon;
          const active = pathname === menu.href;

          return (

            <Link
              key={menu.href}
              href={menu.href}
              className={`mb-3 flex items-center gap-4 rounded-2xl px-5 py-4 transition-all duration-300 ${
                active
                  ? "bg-green-600 shadow-lg"
                  : "hover:bg-slate-900"
              }`}
            >

              <Icon size={22} />

              <span className="font-medium">
                {menu.name}
              </span>

            </Link>

          );

        })}

      </nav>

      <div className="border-t border-slate-800 p-6">

        <div className="rounded-2xl bg-slate-900 p-5">

          <p className="text-sm text-slate-400">
            Monthly Goal
          </p>

          <h2 className="mt-2 text-3xl font-bold">
            68%
          </h2>

          <div className="mt-4 h-2 rounded-full bg-slate-700">

            <div className="h-2 w-2/3 rounded-full bg-green-500"></div>

          </div>

        </div>

        <button className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl border border-slate-700 py-3 transition hover:bg-slate-900">

          <Settings size={18} />

          Settings

        </button>

      </div>

    </aside>
  );
}