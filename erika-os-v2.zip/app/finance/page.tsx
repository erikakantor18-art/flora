"use client";

import { useState } from "react";

import Sidebar from "@/components/layout/Sidebar";
import Topbar from "@/components/layout/Topbar";
import BudgetCard from "@/components/finance/BudgetCard";
import SummaryCards from "@/components/finance/SummaryCards";
import ExpenseForm from "@/components/finance/ExpenseForm";
import ExpenseChart from "@/components/finance/ExpenseChart";
import ExpenseHistory from "@/components/finance/ExpenseHistory";
import SearchBar from "@/components/finance/SearchBar";
import CategoryFilter from "@/components/finance/CategoryFilter";
import AnalyticsCard from "@/components/finance/AnalyticsCard";
import useExpense from "@/hooks/useExpense";
import MonthlySummary from "@/components/finance/MonthlySummary";
import toast from "react-hot-toast";

import { Expense } from "@/types";

export default function Finance() {

  const income = 4700000;

  const {
    expenses,
    totalExpense,
    addExpense,
    updateExpense,
    deleteExpense,
  } = useExpense();

  const [expenseName, setExpenseName] = useState("");
  const [expenseAmount, setExpenseAmount] = useState("");
  const [category, setCategory] = useState("Food");

  const [search, setSearch] = useState("");

  const [filterCategory, setFilterCategory] =
    useState("All");

  const [editingId, setEditingId] =
    useState<string | null>(null);

  const filteredExpenses = expenses.filter((expense) => {

    const matchName = expense.name
      .toLowerCase()
      .includes(search.toLowerCase());

    const matchCategory =
      filterCategory === "All" ||
      expense.category === filterCategory;

    return matchName && matchCategory;

  });

  function handleSave() {

    if (!expenseName || !expenseAmount)
      return;

    const expense: Expense = {

      id: editingId ?? crypto.randomUUID(),

      name: expenseName,

      amount: Number(expenseAmount),

      category,

      createdAt: new Date().toISOString(),

    };

    if (editingId) {

      updateExpense(expense);
      toast.success("Expense berhasil diperbarui");
    } else {

      addExpense(expense);
      toast.success("Expense berhasil ditambahkan");

    }
    

    setExpenseName("");

    setExpenseAmount("");

    setCategory("Food");

    setEditingId(null);

  }

  function handleEdit(id: string) {

    const expense =
      expenses.find((e) => e.id === id);

    if (!expense) return;

    setExpenseName(expense.name);

    setExpenseAmount(
      expense.amount.toString()
    );

    setCategory(expense.category);

    setEditingId(expense.id);

  }

  return (

    <main className="flex min-h-screen bg-slate-100">

      <Sidebar />

      <section className="flex-1 p-8 overflow-y-auto">

        <Topbar />

        <div className="mt-8">

          <SummaryCards

            income={income}

            expense={totalExpense}

          />
        <MonthlySummary
            income={income}
            expense={totalExpense}
        />

        </div>

        <ExpenseForm

          expenseName={expenseName}

          expenseAmount={expenseAmount}

          category={category}

          setExpenseName={setExpenseName}

          setExpenseAmount={setExpenseAmount}

          setCategory={setCategory}

          addExpense={handleSave}

        />

        <SearchBar

          search={search}

          setSearch={setSearch}

        />

        <CategoryFilter

          category={filterCategory}

          setCategory={setFilterCategory}

        />

        <div className="mt-8 grid gap-8 xl:grid-cols-3">

        <div className="space-y-8">

            <ExpenseChart
            expenses={filteredExpenses}
            />

            <BudgetCard
            budget={2000000}
            expense={totalExpense}
            />

        </div>

        <ExpenseHistory
            expenses={filteredExpenses}
            onDelete={(index) => {
            deleteExpense(
            filteredExpenses[index].id
            );

            toast.success("Expense berhasil dihapus");
            }}
            onEdit={(index) => {
            handleEdit(
                filteredExpenses[index].id
            );
            }}
        />

        </div>

      </section>

    </main>

  );

}