"use client";

import { useState } from "react";

import Sidebar from "@/components/layout/Sidebar";
import Topbar from "@/components/layout/Topbar";

import GoalCard from "@/components/goals/GoalCard";

import useGoal from "@/hooks/useGoal";

import { Goal } from "@/types";

export default function Goals() {

  const {
    goals,
    addGoal,
    updateGoal,
    deleteGoal,
  } = useGoal();

  const [title, setTitle] = useState("");
  const [target, setTarget] = useState("");
  const [deadline, setDeadline] = useState("");

  function handleSave() {

    if (!title || !target || !deadline)
      return;

    const goal: Goal = {

      id: crypto.randomUUID(),

      title,

      current: 0,

      target: Number(target),

      deadline,

    };

    addGoal(goal);

    setTitle("");
    setTarget("");
    setDeadline("");

  }

  function handleAddSaving(goal: Goal) {

    const input = prompt(
      `Tambah tabungan untuk "${goal.title}"`,
      "100000"
    );

    if (!input) return;

    const amount = Number(input);

    if (isNaN(amount) || amount <= 0)
      return;

    updateGoal({

      ...goal,

      current: goal.current + amount,

    });

  }

  return (

    <main className="flex min-h-screen bg-slate-100">

      <Sidebar />

      <section className="flex-1 overflow-y-auto p-8">

        <Topbar />

        <div className="rounded-3xl bg-white p-8 shadow">

          <h1 className="text-4xl font-black">

            🎯 Goals

          </h1>

          <p className="mt-2 text-slate-500">

            Build your future one goal at a time.

          </p>

          <div className="mt-8 grid gap-4 md:grid-cols-3">

            <input
              value={title}
              onChange={(e) =>
                setTitle(e.target.value)
              }
              placeholder="Goal Name"
              className="rounded-2xl border border-slate-200 px-5 py-3 outline-none focus:border-green-500"
            />

            <input
              type="number"
              value={target}
              onChange={(e) =>
                setTarget(e.target.value)
              }
              placeholder="Target Amount"
              className="rounded-2xl border border-slate-200 px-5 py-3 outline-none focus:border-green-500"
            />

            <input
              value={deadline}
              onChange={(e) =>
                setDeadline(e.target.value)
              }
              placeholder="Deadline"
              className="rounded-2xl border border-slate-200 px-5 py-3 outline-none focus:border-green-500"
            />

          </div>

          <button
            onClick={handleSave}
            className="mt-6 rounded-2xl bg-green-600 px-6 py-3 font-semibold text-white hover:bg-green-700"
          >

            + Add Goal

          </button>

        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-2">

          {goals.length === 0 ? (

            <div className="col-span-2 rounded-3xl bg-white p-12 text-center shadow">

              <p className="text-7xl">

                🎯

              </p>

              <h2 className="mt-5 text-2xl font-bold">

                No Goals Yet

              </h2>

              <p className="mt-2 text-slate-500">

                Create your first goal.

              </p>

            </div>

          ) : (

            goals.map((goal) => (

              <GoalCard

                key={goal.id}

                title={goal.title}

                current={goal.current}

                target={goal.target}

                deadline={goal.deadline}

                onAddSaving={() =>
                  handleAddSaving(goal)
                }

                onDelete={() =>
                  deleteGoal(goal.id)
                }

              />

            ))

          )}

        </div>

      </section>

    </main>

  );

}