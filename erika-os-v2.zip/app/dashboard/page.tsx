import Sidebar from "@/components/Sidebar";
import Topbar from "@/components/layout/Topbar";

export default function Dashboard() {
  return (
    <main className="flex h-screen bg-slate-100">

      {/* Sidebar */}
      <Sidebar />

      {/* Content */}
      <section className="flex-1 overflow-auto p-8">

        <Topbar />

        {/* Summary Cards */}
        <div className="mt-8 grid gap-6 md:grid-cols-2 xl:grid-cols-4">

          <div className="rounded-3xl bg-white p-8 shadow transition hover:-translate-y-1 hover:shadow-xl">

            <p className="text-slate-500">
              💰 Finance
            </p>

            <h2 className="mt-3 text-4xl font-black">
              Rp0
            </h2>

            <p className="mt-3 text-green-600">
              +0% bulan ini
            </p>

          </div>

          <div className="rounded-3xl bg-white p-8 shadow transition hover:-translate-y-1 hover:shadow-xl">

            <p className="text-slate-500">
              🎯 Goals
            </p>

            <h2 className="mt-3 text-4xl font-black">
              0
            </h2>

            <p className="mt-3 text-blue-600">
              Active Goals
            </p>

          </div>

          <div className="rounded-3xl bg-white p-8 shadow transition hover:-translate-y-1 hover:shadow-xl">

            <p className="text-slate-500">
              📚 Study
            </p>

            <h2 className="mt-3 text-4xl font-black">
              0%
            </h2>

            <p className="mt-3 text-orange-600">
              Learning Progress
            </p>

          </div>

          <div className="rounded-3xl bg-white p-8 shadow transition hover:-translate-y-1 hover:shadow-xl">

            <p className="text-slate-500">
              🇦🇺 Australia Fund
            </p>

            <h2 className="mt-3 text-4xl font-black">
              Rp0
            </h2>

            <p className="mt-3 text-purple-600">
              Target 2029
            </p>

          </div>

        </div>

        {/* Dashboard Grid */}
        <div className="mt-8 grid gap-6 xl:grid-cols-3">

          {/* Left */}
          <div className="xl:col-span-2">

            <div className="rounded-3xl bg-white p-8 shadow">

              <h2 className="text-2xl font-bold">
                📈 Dashboard Overview
              </h2>

              <p className="mt-2 text-slate-500">
                Selamat datang di Erika OS V2.
              </p>

              <div className="mt-8 flex h-80 items-center justify-center rounded-2xl border-2 border-dashed border-slate-300">

                <p className="text-slate-400 text-xl">
                  Chart Coming Soon 📊
                </p>

              </div>

            </div>

          </div>

          {/* Right */}
          <div>

            <div className="rounded-3xl bg-white p-8 shadow">

              <h2 className="text-2xl font-bold">
                🕒 Recent Activity
              </h2>

              <div className="mt-6 space-y-4">

                <div className="rounded-2xl bg-slate-50 p-4">
                  🍔 Belum ada aktivitas
                </div>

                <div className="rounded-2xl bg-slate-50 p-4">
                  💰 Tambahkan data Finance
                </div>

                <div className="rounded-2xl bg-slate-50 p-4">
                  🎯 Buat Goals pertama
                </div>

              </div>

            </div>

          </div>

        </div>

      </section>

    </main>
  );
}