export interface Study {
  id: string;
  title: string;
  progress: number;
}